# Example sudoers file for running `socket_vmnet`

To allow non-root users to run `socket_vmnet`, use [launchd](../launchd) *or*
install [the `socket_vmnet` file in this directory](./socket_vmnet) as `/etc/sudoers.d/socket_vmnet`.

See the comment lines in the file for the further information.
