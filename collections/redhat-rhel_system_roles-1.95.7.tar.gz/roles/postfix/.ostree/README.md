*NOTE*: The `*.txt` files are used by `get_ostree_data.sh` to create the lists
of packages, and to find other system roles used by this role.  DO NOT use them
directly.
